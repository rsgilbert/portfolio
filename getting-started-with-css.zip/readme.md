# Getting Started with CSS

Frontend Masters course.


# Setup
To setup up live-reload for the local directory files, ensure Python3 is installed and 
then run below command from terminal:
python -m http.server


